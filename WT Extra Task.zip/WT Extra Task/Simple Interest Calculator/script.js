$(function () {
  $("#datepicker1").datepicker({
      changeMonth: true,
      changeYear: true,
      dateFormat: "mm-d-y"
  });
  $("#datepicker2").datepicker({
      changeMonth: true,
      changeYear: true,
      dateFormat: "mm-d-y"
  });
});
function MonthDifference(d1, d2) {
  var months;
  months = (d2.getFullYear() - d1.getFullYear()) * 12;
  months -= d1.getMonth();
  months += d2.getMonth();
  return months <= 0 ? 0 : months;
}
let calculateBtn = document.getElementById("calculate-btn");
let result = document.getElementById("result");
function calculate() {
  let p = Number(document.getElementById("principal").value);
  let r = Number(document.getElementById("rate").value);
  let d1 = new Date($("#datepicker1").val());
  let d2 = new Date($("#datepicker2").val());
  let t = MonthDifference(d1, d2);

  let simpleInterest = (p * r * t) / 1200;
  alert("Simple intrest is " + simpleInterest);
}
calculateBtn.addEventListener("click", calculate);
window.addEventListener("load", calculate);

